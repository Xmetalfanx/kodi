# SPDX-License-Identifier: GPL-3.0-or-later

__all__ = ["localsettings", "kodisettings"]
